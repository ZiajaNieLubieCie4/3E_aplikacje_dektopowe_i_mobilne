﻿using System;
/*
namespace Zadanie2
{
    class Zadanie2
    {
        public static void Main(string[] args)
        {
            Random rnd = new Random();
            int Losowana = rnd.Next(1, 10);

            Console.WriteLine("Odgadnij liczbe!");
            int Zgadywana = Convert.ToInt32(Console.ReadLine());
            if (Zgadywana == Losowana)
            {
                Console.WriteLine("Brawo zgadles! Wylosowana liczba to: " + Losowana);
            }
            else
            {
                do
                {
                    Console.WriteLine("Błąd! Podaj jeszcze raz: ");
                    Zgadywana = Convert.ToInt32((Console.ReadLine()));

                } while (Zgadywana != Losowana);
                Console.WriteLine("Brawo zgadles! Wylosowana liczba to: " + Losowana);
            }
        }
    }
}
*/