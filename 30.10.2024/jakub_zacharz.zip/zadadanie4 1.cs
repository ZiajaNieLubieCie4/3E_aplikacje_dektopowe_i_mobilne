﻿using System;
/*
namespace Zadanie4
{
    class Zadanie4
    {
        public static void Main(string[] args)
        {
            int Wybor;
            do
            {
                Console.WriteLine("Wybierz: \nDodawanie 1\nOdejmowanie 2\nMnozenie 3\nDzielenie 4\n");
                Wybor = Convert.ToInt32(Console.ReadLine());

            } while (Wybor > 4 || Wybor < 1);

            Console.WriteLine("Wybrano");


        }
    }
}
*/