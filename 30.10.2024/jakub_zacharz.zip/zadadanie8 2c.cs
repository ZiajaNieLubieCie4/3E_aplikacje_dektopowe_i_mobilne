﻿using System;
/*
namespace Zadanie8a
{
    class Zadanie8a
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj liczby, ujemna liczba konczy program");
            int Suma = 0;
            int Liczba = 0;
            for(int i = 1; i != 0;)
            {
                Suma += Liczba;
                Liczba = Convert.ToInt32((Console.ReadLine()));
                if(Liczba < 0)
                {
                    i = 0;
                }
            }
            Console.WriteLine(Suma);
        }
    }
}
*/