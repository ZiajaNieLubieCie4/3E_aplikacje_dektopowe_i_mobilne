﻿using System;
/*
namespace Zadanie9a
{
    class Zadanie9a
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj poczatek przedzialu");
            int przedzialStartPodany = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Podaj koniec przedzialu");
            int przedzialKoniecPodany = Convert.ToInt32(Console.ReadLine());

            int przedzialStart;
            int przedzialKoniec;

            if (przedzialStartPodany > przedzialKoniecPodany)
            {
                przedzialStart = przedzialKoniecPodany;
                przedzialKoniec = przedzialStartPodany;
            }
            else
            {
                przedzialStart = przedzialStartPodany;
                przedzialKoniec = przedzialKoniecPodany;
            }

            for(int i = przedzialStart; i <= przedzialKoniec; i++)
            {
                if(i % 3 == 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
*/