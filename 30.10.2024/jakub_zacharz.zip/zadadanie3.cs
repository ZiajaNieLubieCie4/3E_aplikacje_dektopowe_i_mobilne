﻿using System;

/*
namespace Zadanie3
{
    class Zadanie3
    {
        public static void Main(string[] args)
        {
            int Liczba;
            do
            {
                Console.WriteLine("Podaj liczbe");
                Liczba = Convert.ToInt32(Console.ReadLine());
            } while (Liczba <= 0);

            int Silnia = 1;

            if (Liczba == 1)
            {
                Console.WriteLine("Silnia tej liczby to: 1");
            }
            else
            {
                do
                {
                    Silnia *= Liczba;
                    Liczba--;
                } while (Liczba != 1);

                Console.WriteLine("Silnia tej liczby to: " + Silnia);
            }
        }
    }
}
*/