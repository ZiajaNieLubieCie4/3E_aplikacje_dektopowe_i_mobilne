﻿using System;
/*
namespace Zadanie8c
{
    class Zadanie8c
    {
        public static void Main(string[] args)
        {
            int Liczba = 0;
            int Suma = 0;
            Console.WriteLine("Podaj liczbe");

            do
            {
                Suma += Liczba;
                Liczba = Convert.ToInt32(Console.ReadLine());
            } while (Liczba >= 0);

            Console.WriteLine(Suma);
        }
    }
}
*/