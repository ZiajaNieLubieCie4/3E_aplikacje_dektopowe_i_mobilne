﻿using System;

/*
namespace Zadanie6
{
    class Zadanie6
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj poczatek przedzialu");
            int przedzialStartPodany = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Podaj koniec przedzialu");
            int przedzialKoniecPodany = Convert.ToInt32(Console.ReadLine());

            int przedzialStart;
            int przedzialKoniec;

            if(przedzialStartPodany > przedzialKoniecPodany)
            {
                przedzialStart = przedzialKoniecPodany;
                przedzialKoniec = przedzialStartPodany;
            }
            else
            {
                przedzialStart = przedzialStartPodany;
                przedzialKoniec = przedzialKoniecPodany;
            }

            Console.WriteLine("\nPętla for");
            for(int i = przedzialStart; i <= przedzialKoniec; i++)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("\nPętla while");
            int y = przedzialStart;

            while (y <= przedzialKoniec)
            {
                Console.WriteLine(y);
                y++;
            }

            Console.WriteLine("\nPętla do while");
            int z = przedzialStart;

            do
            {
                Console.WriteLine(z);
                z++;
            } while (z <= przedzialKoniec);
        }
    }
}
*/