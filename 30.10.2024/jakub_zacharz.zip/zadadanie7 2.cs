﻿using System;
/*
namespace Zadanie7
{
    class Zadanie7
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj poczatek przedzialu");
            int przedzialStartPodany = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Podaj koniec przedzialu");
            int przedzialKoniecPodany = Convert.ToInt32(Console.ReadLine());

            int przedzialStart;
            int przedzialKoniec;

            if (przedzialStartPodany > przedzialKoniecPodany)
            {
                przedzialStart = przedzialKoniecPodany;
                przedzialKoniec = przedzialStartPodany;
            }
            else
            {
                przedzialStart = przedzialStartPodany;
                przedzialKoniec = przedzialKoniecPodany;
            }

            
            int Suma = 0;
            for(int i = przedzialStart; i <= przedzialKoniec; i++)
            {
                Suma += i;
            }

            Console.WriteLine("Suma liczb (for): " + Suma);


            Suma = 0;

            int y = przedzialStart;
            while(y <= przedzialKoniec)
            {
                Suma += y;
                y++;
            }

            Console.WriteLine("Suma liczb (while): " + Suma);

            Suma = 0;

            int z = przedzialStart;

            do
            {
                Suma += z;
                z++;
            } while (z <= przedzialKoniec);
            Console.WriteLine("Suma liczb (do while): " + Suma);
        }
    }
}
*/