﻿using System;
/*
namespace Zadanie5
{
    class Zadanie5
    {
        public static void Main(string[] args)
        {
            string haslo = "dupa123";
            string wprowadzane;
            do
            {
                Console.WriteLine("Podaj haslo: ");
                wprowadzane = Console.ReadLine();
            } while (wprowadzane != haslo);

            Console.WriteLine("Zalogowano");

        } 
    } 
}
*/