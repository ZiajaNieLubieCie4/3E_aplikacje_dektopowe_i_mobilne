﻿using System;
/*
namespace Zadanie9c
{
    class Zadanie9c
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj poczatek przedzialu");
            int przedzialStartPodany = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Podaj koniec przedzialu");
            int przedzialKoniecPodany = Convert.ToInt32(Console.ReadLine());

            int przedzialStart;
            int przedzialKoniec;

            if (przedzialStartPodany > przedzialKoniecPodany)
            {
                przedzialStart = przedzialKoniecPodany;
                przedzialKoniec = przedzialStartPodany;
            }
            else
            {
                przedzialStart = przedzialStartPodany;
                przedzialKoniec = przedzialKoniecPodany;
            }

            do
            {
                if(przedzialStart % 3 == 0)
                {
                    Console.WriteLine(przedzialStart);
                }
                przedzialStart++;
            } while (przedzialStart <= przedzialKoniec);
        }
    }
}
*/